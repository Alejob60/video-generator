export declare class SoraModule {
}
