export declare class InfluencerModule {
}
