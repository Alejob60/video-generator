export declare class FluxImageModule {
}
