export declare class ImageGenerationModule {
}
