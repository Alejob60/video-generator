export declare class WebsiteDnaModule {
}
