export declare class AzureModule {
}
