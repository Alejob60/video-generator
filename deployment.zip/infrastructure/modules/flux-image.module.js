"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FluxImageModule = void 0;
const common_1 = require("@nestjs/common");
const flux_image_service_1 = require("../services/flux-image.service");
const flux_kontext_image_service_1 = require("../services/flux-kontext-image.service");
const flux_2_pro_service_1 = require("../services/flux-2-pro.service");
const azure_blob_service_1 = require("../services/azure-blob.service");
const llm_service_1 = require("../services/llm.service");
const flux_image_controller_1 = require("../../interfaces/controllers/flux-image.controller");
const flux_kontext_image_controller_1 = require("../../interfaces/controllers/flux-kontext-image.controller");
const promo_image_module_1 = require("./promo-image.module");
let FluxImageModule = class FluxImageModule {
};
exports.FluxImageModule = FluxImageModule;
exports.FluxImageModule = FluxImageModule = __decorate([
    (0, common_1.Module)({
        imports: [(0, common_1.forwardRef)(() => promo_image_module_1.PromoImageModule)],
        controllers: [
            flux_image_controller_1.FluxImageController,
            flux_kontext_image_controller_1.FluxKontextImageController,
        ],
        providers: [
            flux_image_service_1.FluxImageService,
            flux_kontext_image_service_1.FluxKontextImageService,
            flux_2_pro_service_1.Flux2ProService,
            azure_blob_service_1.AzureBlobService,
            llm_service_1.LLMService
        ],
        exports: [flux_image_service_1.FluxImageService, flux_kontext_image_service_1.FluxKontextImageService, flux_2_pro_service_1.Flux2ProService],
    })
], FluxImageModule);
//# sourceMappingURL=flux-image.module.js.map