export declare class PromoImageModule {
}
