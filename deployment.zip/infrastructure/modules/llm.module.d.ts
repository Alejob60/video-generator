export declare class LLMModule {
}
