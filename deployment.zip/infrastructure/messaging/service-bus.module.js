"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceBusModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const service_bus_service_1 = require("../services/service-bus.service");
const video_queue_consumer_service_1 = require("../services/video-queue-consumer.service");
const video_module_1 = require("../modules/video.module");
let ServiceBusModule = class ServiceBusModule {
};
exports.ServiceBusModule = ServiceBusModule;
exports.ServiceBusModule = ServiceBusModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule,
            video_module_1.VideoModule,
        ],
        providers: [
            service_bus_service_1.ServiceBusService,
            video_queue_consumer_service_1.VideoQueueConsumerService,
        ],
        exports: [service_bus_service_1.ServiceBusService],
    })
], ServiceBusModule);
//# sourceMappingURL=service-bus.module.js.map