export declare class ServiceBusModule {
}
