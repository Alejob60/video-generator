"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenerateInfluencerDto = void 0;
const class_validator_1 = require("class-validator");
class GenerateInfluencerDto {
}
exports.GenerateInfluencerDto = GenerateInfluencerDto;
__decorate([
    (0, class_validator_1.IsUrl)(),
    __metadata("design:type", String)
], GenerateInfluencerDto.prototype, "imageUrl", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(10, { message: 'El script debe tener al menos 10 caracteres' }),
    __metadata("design:type", String)
], GenerateInfluencerDto.prototype, "script", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(1, { message: 'El ID de voz es requerido' }),
    __metadata("design:type", String)
], GenerateInfluencerDto.prototype, "voiceId", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsIn)(['free', 'pro']),
    __metadata("design:type", String)
], GenerateInfluencerDto.prototype, "plan", void 0);
//# sourceMappingURL=generate-influencer.dto.js.map