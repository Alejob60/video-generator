import { FluxKontextImageService } from '../../infrastructure/services/flux-kontext-image.service';
import { GenerateFluxImageDto } from '../dto/generate-flux-image.dto';
export declare class FluxKontextImageController {
    private readonly fluxKontextService;
    private readonly logger;
    constructor(fluxKontextService: FluxKontextImageService);
    generateFromText(dto: GenerateFluxImageDto, userId?: string): Promise<{
        success: boolean;
        message: string;
        data: {
            imageUrl: string;
            prompt: string;
            filename: string;
        };
    }>;
}
