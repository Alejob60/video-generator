"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var FluxKontextImageController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FluxKontextImageController = void 0;
const common_1 = require("@nestjs/common");
const flux_kontext_image_service_1 = require("../../infrastructure/services/flux-kontext-image.service");
const generate_flux_image_dto_1 = require("../dto/generate-flux-image.dto");
let FluxKontextImageController = FluxKontextImageController_1 = class FluxKontextImageController {
    constructor(fluxKontextService) {
        this.fluxKontextService = fluxKontextService;
        this.logger = new common_1.Logger(FluxKontextImageController_1.name);
    }
    async generateFromText(dto, userId = 'anon') {
        try {
            this.logger.log(`📸 Generating FLUX Kontext image for user: ${userId}`);
            this.logger.log(`📝 Prompt: ${dto.prompt}`);
            this.logger.log(`📏 Size: ${dto.size || '1024x1024'}`);
            const result = await this.fluxKontextService.generateImageAndNotify(userId, dto);
            return {
                success: true,
                message: '✅ FLUX Kontext image generated successfully',
                data: {
                    imageUrl: result.imageUrl,
                    prompt: result.prompt,
                    filename: result.filename,
                },
            };
        }
        catch (error) {
            this.logger.error(`❌ Error: ${error.message}`, error.stack);
            throw new Error(`FLUX Kontext generation failed: ${error.message}`);
        }
    }
};
exports.FluxKontextImageController = FluxKontextImageController;
__decorate([
    (0, common_1.Post)('flux-kontext/image'),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)('x-user-id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [generate_flux_image_dto_1.GenerateFluxImageDto, String]),
    __metadata("design:returntype", Promise)
], FluxKontextImageController.prototype, "generateFromText", null);
exports.FluxKontextImageController = FluxKontextImageController = FluxKontextImageController_1 = __decorate([
    (0, common_1.Controller)('media'),
    __metadata("design:paramtypes", [flux_kontext_image_service_1.FluxKontextImageService])
], FluxKontextImageController);
//# sourceMappingURL=flux-kontext-image.controller.js.map